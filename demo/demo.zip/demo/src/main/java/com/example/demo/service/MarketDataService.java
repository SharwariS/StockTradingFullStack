package com.example.demo.service;

import com.example.demo.model.MarketData;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class MarketDataService {

    private final SimpMessagingTemplate messagingTemplate;

    public MarketDataService(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    // Scheduled task to simulate streaming data (replace with Alpaca integration)
    @Scheduled(fixedRate = 1000)
    public void sendMarketData() {
        MarketData marketData = generateMarketData();
        messagingTemplate.convertAndSend("/topic/stocks", marketData);
    }

    // Replace this method with Alpaca integration to get real market data
    private MarketData generateMarketData() {
        // Mock implementation for demonstration purposes
        return new MarketData("AAPL", Math.random() * 1000);
    }
}