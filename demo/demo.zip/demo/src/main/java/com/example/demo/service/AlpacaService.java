package com.example.demo.service;

import com.example.demo.model.MarketData;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

@Service
public class AlpacaService {

    @Value("${alpaca.api.key}")
    private String apiKey;

    @Value("${alpaca.api.secret}")
    private String apiSecret;

    private final RestTemplate restTemplate;

    public AlpacaService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    // Method to get real market data for the specified symbol from Alpaca API
    public MarketData getMarketData(String symbol) {
        // Construct Alpaca API endpoint URL
        String apiUrl = "https://paper-api.alpaca.markets/v2/stocks/" + symbol + "/quote";

        // Set up request headers with API key
        HttpHeaders headers = new HttpHeaders();
        headers.set("APCA-API-KEY-ID", apiKey);
        headers.set("APCA-API-SECRET-KEY", apiSecret);

        // Build the request entity with headers
        RequestEntity<Void> requestEntity = new RequestEntity<>(headers, HttpMethod.GET, URI.create(apiUrl));

        // Make the API request
        ResponseEntity<MarketData> responseEntity = restTemplate.exchange(requestEntity, MarketData.class);

        // Check if the request was successful
        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return responseEntity.getBody();
        } else {
            // Handle error scenario (throw an exception or return a default MarketData object)
            return new MarketData();
        }
    }
}