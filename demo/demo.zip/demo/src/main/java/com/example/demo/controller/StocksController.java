package com.example.demo.controller;

import com.example.demo.model.MarketData;
import com.example.demo.service.AlpacaService;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

@Controller
public class StocksController {

    private final AlpacaService alpacaService;

    public StocksController(AlpacaService alpacaService) {
        this.alpacaService = alpacaService;
    }

    @MessageMapping("/subscribe")
    @SendTo("/topic/stocks")
    public MarketData subscribe(String symbol) {
        // Use AlpacaService to get real market data for the specified symbol
        // For demonstration, let's assume AlpacaService provides the data
        return alpacaService.getMarketData(symbol);
    }
}